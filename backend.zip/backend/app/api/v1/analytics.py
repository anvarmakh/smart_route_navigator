from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from app.models.route_history import RouteHistory
from database import get_db
import statistics

router = APIRouter()

@router.get("/analytics/")
def route_analytics(request: Request, db: Session = Depends(get_db)):
    """
    Возвращает базовую аналитику по маршрутам пользователя:
    - средняя цена топлива
    - популярные направления
    - частота плохой погоды
    """
    user = request.state.user
    history = db.query(RouteHistory).filter_by(user_id=user["id"]).all()

    if not history:
        return {"message": "Нет данных"}

    # Средняя цена топлива
    fuel_prices = []
    weather_tags = []
    route_pairs = []

    for h in history:
        for item in h.fuel_data:
            fuel_prices.extend(item.values())
        for item in h.weather_data:
            weather_tags.extend(item.values())
        route_pairs.append((h.origin, h.destination))

    avg_fuel = round(statistics.mean(fuel_prices), 2) if fuel_prices else None
    common_weather = {k: weather_tags.count(k) for k in set(weather_tags)}
    common_routes = {f"{a} → {b}": route_pairs.count((a, b)) for a, b in set(route_pairs)}

    return {
        "average_fuel_price": avg_fuel,
        "weather_distribution": common_weather,
        "most_common_routes": common_routes
    }
