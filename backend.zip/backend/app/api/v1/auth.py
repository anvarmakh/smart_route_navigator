from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from app.database import get_db
from app.services.auth_service import (
    get_current_user,
    verify_password,
    get_password_hash,
    create_access_token,
)
from app.models.user import UserCreate
from app.models.user import User
from app.models.truck_profile import TruckProfile

router = APIRouter()

# 🔐 Логин: получение токена
@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.password):
        raise HTTPException(status_code=400, detail="Invalid credentials")
    token = create_access_token({"user_id": user.id})
    return {"access_token": token, "token_type": "bearer"}

# 🧾 Регистрация пользователя
@router.post("/register")
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter_by(email=user_data.email).first():
        raise HTTPException(status_code=400, detail="User already exists")

    hashed_password = get_password_hash(user_data.password)
    new_user = User(email=user_data.email, password=hashed_password)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # создаём профиль трака по умолчанию
    truck = TruckProfile(user_id=new_user.id, make="", model="", year=2020, fuel_capacity=150, mpg=6.0)
    db.add(truck)
    db.commit()

    return {"message": "User created successfully"}

# 🚛 Получение профиля трака
@router.get("/api/v1/profile/truck")
def get_truck_profile(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    truck = db.query(TruckProfile).filter_by(user_id=current_user.id).first()
    if not truck:
        raise HTTPException(status_code=404, detail="Truck profile not found")

    return {
        "make": truck.make,
        "model": truck.model,
        "year": truck.year,
        "fuel_capacity": truck.fuel_capacity,
        "mpg": truck.mpg
    }
