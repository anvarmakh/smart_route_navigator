# Этот модуль предоставляет GET-запрос для получения цен на топливо по координатам
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from database import get_db
from services.fuel import rank_fuel_stops_by_brand

router = APIRouter()

@router.post("/fuel/recommendations")
def recommend_stops(request: Request, db: Session = Depends(get_db)):
    """
    Возвращает отсортированные заправки на основе всех факторов
    """
    body = request.json()

    stops = body.get("stops", [])  # список точек: [{brand, price, weather, driver_time_left}, ...]
    preferred_brands = body.get("preferred_brands", [])
    fuel_level = body.get("fuel_level", 100)
    fuel_capacity = body.get("fuel_capacity", 300)
    preferences = body.get("preferences", {
        "fuel_price": "mid",
        "HOS_time_left": "mid",
        "weather_safety": "mid"
    })

    ranked = rank_fuel_stops_by_brand(
        stops=stops,
        preferred_brands=preferred_brands,
        fuel_level=fuel_level,
        fuel_capacity=fuel_capacity,
        preferences=preferences
    )
    return {"recommendations": ranked}