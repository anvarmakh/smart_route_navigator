from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from app.models.route_history import RouteHistory
from app.database import get_db

router = APIRouter()

@router.get("/history/")
def get_route_history(request: Request, db: Session = Depends(get_db)):
    """
    Возвращает историю маршрутов пользователя
    """
    user = request.state.user
    history = db.query(RouteHistory).filter_by(user_id=user["id"]).order_by(RouteHistory.created_at.desc()).all()
    return [
        {
            "origin": h.origin,
            "destination": h.destination,
            "distance": h.distance,
            "estimated_time": h.estimated_time,
            "fuel_data": h.fuel_data,
            "weather_data": h.weather_data,
            "created_at": h.created_at.isoformat()
        }
        for h in history
    ]
