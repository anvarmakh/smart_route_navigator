# Этот модуль обрабатывает POST-запросы для построения маршрутов с учётом ограничений
from fastapi import APIRouter, Query
from app.services.route_service import build_route

router = APIRouter()

@router.post("/route-info/")
def route_info(
    origin: str = Query(..., description="Начальная точка"),
    destination: str = Query(..., description="Конечная точка"),
    height: float = Query(..., description="Высота трака в метрах"),
    weight: int = Query(..., description="Вес трака в кг")
):
    """Построение маршрута с учётом ограничений по высоте и весу"""
    return build_route(origin, destination, height, weight)

