from fastapi import APIRouter, Request, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import get_db
import redis
import os
from app.services.route_service import build_route
from integrations.samsara_provider import get_samsara_vehicle_info
from geopy.distance import geodesic  # 📍 для расчета расстояния между точками
from app.services.alert_service import notify_all_channels  # ✉️ подключаем уведомления

router = APIRouter()

# Подключение к Redis
redis_client = redis.Redis(
    host=os.getenv("REDIS_HOST", "localhost"),
    port=int(os.getenv("REDIS_PORT", 6379)),
    db=0,
    decode_responses=True
)

# 📍 Модель для приёма координат водителя
class LocationPayload(BaseModel):
    latitude: float
    longitude: float
    timestamp: str

# 🚚 Приём текущей координаты водителя
@router.post("/telemetry/location")
def update_driver_location(
    payload: LocationPayload,
    request: Request,
    db: Session = Depends(get_db)
):
    user = request.state.user
    key = f"driver:{user['id']}:location"

    # Сохраняем координату в Redis
    redis_client.hmset(key, {
        "lat": payload.latitude,
        "lon": payload.longitude,
        "ts": payload.timestamp
    })
    redis_client.expire(key, 3600)

    # 🔔 Проверка отклонения от маршрута (если сохранена цель)
    route_key = f"driver:{user['id']}:route_destination"
    dest = redis_client.get(route_key)
    if dest:
        current = (payload.latitude, payload.longitude)
        try:
            dest_lat, dest_lon = map(float, dest.split(","))
            distance = geodesic(current, (dest_lat, dest_lon)).miles
            if distance > 25:
                alert_msg = f"🚨 Driver ID {user['id']} отклонился от маршрута на {distance:.1f} миль."
                print(f"[ALERT] {alert_msg}")
                notify_all_channels(subject="Driver Deviation Alert", message=alert_msg)
        except Exception as e:
            print("[WARN] Unable to check deviation:", e)

    return {"message": "Location updated"}

# 🗺️ Построение маршрута от текущей позиции
@router.get("/route/from-current")
def build_route_from_current_location(
    destination: str,
    request: Request,
    db: Session = Depends(get_db)
):
    user = request.state.user
    key = f"driver:{user['id']}:location"
    position = redis_client.hgetall(key)

    if not position:
        return {"error": "No position found for user"}

    origin = f"{position['lat']},{position['lon']}"

    # Сохраняем цель маршрута в Redis
    redis_client.set(f"driver:{user['id']}:route_destination", destination, ex=3600)

    # 🔌 Получаем данные от Samsara
    samsara_data = get_samsara_vehicle_info(user_id=user["id"])
    fuel_level = samsara_data.get("fuel_level", 200)
    driver_time_left = samsara_data.get("driver_time_left", 4)
    weather_condition = samsara_data.get("weather", "Clear")

    # 🧭 Вызываем маршрутизатор
    return build_route(
        origin=origin,
        destination=destination,
        height=13.6,
        weight=80000,
        driver_time_left=driver_time_left,
        weather_condition=weather_condition,
        preferences={
            "fuel_price": "mid",
            "HOS_time_left": "mid",
            "weather_safety": "mid"
        },
        db=db,
        user_id=user["id"]
    )