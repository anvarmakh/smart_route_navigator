# Этот модуль возвращает погодные условия вдоль заданного маршрута
from fastapi import APIRouter
from app.services.weather import get_weather_along_route

router = APIRouter()

@router.post("/weather/")
def weather_info(coords: list[tuple[float, float]]):
    """Получение погодных условий вдоль маршрута"""
    return get_weather_along_route(coords)