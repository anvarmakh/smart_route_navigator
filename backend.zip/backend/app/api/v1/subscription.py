# Модуль для проверки доступа к функциональности на основе активной подписки
from fastapi import APIRouter, HTTPException, Request
from app.services.subscription_service import check_user_plan

router = APIRouter()

@router.get("/check-access")
def check_access(request: Request, feature: str):
    """Проверка доступа пользователя к функционалу согласно его подписке"""
    if not check_user_plan(request.state.user, feature):
        raise HTTPException(status_code=403, detail="Недостаточный уровень подписки")
    return {"access": True}
