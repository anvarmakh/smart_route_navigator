# ✅ database.py — подключение к PostgreSQL через SQLAlchemy

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# 📦 URL подключения берётся из .env
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:password@localhost:5432/smart_route")

# 🔌 Подключение к БД
engine = create_engine(DATABASE_URL)

# ⚙️ Создание фабрики сессий
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 📐 Базовый класс для моделей
Base = declarative_base()

# 📥 Зависимость для получения сессии в endpoint'ах

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
