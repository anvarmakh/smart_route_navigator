# Модель подписки, включающая план и статус
from sqlalchemy import Column, Integer, String, Boolean
from sqlalchemy.orm import relationship
from database import Base

class Subscription(Base):
    __tablename__ = "subscriptions"
    id = Column(Integer, primary_key=True, index=True)
    plan_name = Column(String)  # basic / premium / fleet
    is_active = Column(Boolean, default=True)

    users = relationship("User", back_populates="subscription")