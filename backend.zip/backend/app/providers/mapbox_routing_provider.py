# Альтернатива маршрутизации через Mapbox
import requests
from app.core.interfaces.routing_provider import RoutingProvider
import os

class MapboxRoutingProvider(RoutingProvider):
    def __init__(self):
        self.api_key = os.getenv("MAPBOX_TOKEN", "demo_token")

    def geocode(self, location):
        """Преобразует адрес в координаты через Mapbox Geocoding API"""
        url = f"https://api.mapbox.com/geocoding/v5/mapbox.places/{location}.json"
        params = {"access_token": self.api_key, "limit": 1}
        res = requests.get(url, params=params)
        res.raise_for_status()
        data = res.json()
        coords = data["features"][0]["center"]  # [lon, lat]
        return coords[0], coords[1]

    def get_route(self, origin, destination, height, weight):
        """Строит маршрут между двумя точками по координатам"""
        lon1, lat1 = self.geocode(origin)
        lon2, lat2 = self.geocode(destination)

        url = f"https://api.mapbox.com/directions/v5/mapbox/driving/{lon1},{lat1};{lon2},{lat2}"
        params = {
            "access_token": self.api_key,
            "geometries": "geojson",
            "overview": "full"
        }
        res = requests.get(url, params=params)
        res.raise_for_status()
        data = res.json()

        route = data["routes"][0]
        return {
            "route": route["geometry"]["coordinates"],
            "distance_miles": route["distance"] / 1609.34,
            "eta_hours": route["duration"] / 3600
        }
