from app.models.route_history import RouteHistory
from sqlalchemy.orm import Session
from app.providers.mapbox_routing_provider import MapboxRoutingProvider
import logging

# Логгер маршрутизации
logger = logging.getLogger("routing")

# Основная функция построения маршрута с использованием Mapbox
# Получает координаты, рассчитывает маршрут, сохраняет в БД

def build_route(origin, destination, height, weight, driver_time_left, weather_condition, preferences: dict, db: Session, user_id: int):
    """
    Построение маршрута с использованием Mapbox и сохранением истории маршрута.
    Аргументы:
        origin (str): адрес отправления
        destination (str): адрес назначения
        height (float): высота транспортного средства
        weight (int): вес транспортного средства
        driver_time_left (float): оставшееся время вождения
        weather_condition (str): погодные условия
        preferences (dict): предпочтения пользователя (пока не используются)
        db (Session): сессия SQLAlchemy
        user_id (int): ID текущего пользователя
    """
    mapbox = MapboxRoutingProvider()

    try:
        result = mapbox.get_route(origin, destination, height, weight)
    except Exception as e:
        logger.error(f"Ошибка маршрутизации для {origin} -> {destination}: {str(e)}")
        return {
            "origin": origin,
            "destination": destination,
            "error": str(e),
            "saved": False
        }

    # Извлекаем результат маршрута
    total_miles = result["distance_miles"]
    estimated_hours = result["eta_hours"]

    # Сохраняем маршрут в историю пользователя
    try:
        history = RouteHistory(
            user_id=user_id,
            origin=origin,
            destination=destination,
            distance=total_miles,
            estimated_time=estimated_hours,
            fuel_data=[],     # пока заглушка
            weather_data=[]   # пока заглушка
        )
        db.add(history)
        db.commit()
    except Exception as e:
        logger.error(f"Ошибка при сохранении маршрута в БД: {str(e)}")

    # Возвращаем результат клиенту
    return {
        "origin": origin,
        "destination": destination,
        "coordinates": result["route"],
        "distance_miles": total_miles,
        "eta_hours": estimated_hours,
        "saved": True
    }
