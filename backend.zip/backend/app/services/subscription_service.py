# Проверка наличия доступа к функциональности на основе подписки

ACTIVE_PLANS = {
    "basic": ["route"],
    "premium": ["route", "fuel", "weather"]
}

def check_user_plan(user: dict, feature: str) -> bool:
    """
    Проверяет, входит ли функциональность в активную подписку пользователя.
    user — словарь с ключом 'subscription'
    """
    plan = user.get("subscription", "basic")
    return feature in ACTIVE_PLANS.get(plan, [])
